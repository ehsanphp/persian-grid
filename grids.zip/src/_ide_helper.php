<?php
use Nayjest\Grids\Grids as Base;
class Grids extends Base {}
