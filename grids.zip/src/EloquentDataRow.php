<?php
namespace Nayjest\Grids;

/**
 * @deprecated
 * Class EloquentDataRow
 * @package Nayjest\Grids
 */
class EloquentDataRow extends ObjectDataRow
{
}
