<span class="showing_records">
    نمایش سطر <?= $from ?> تا <?= $to ?> از <?= $total ?>
</span>
